using System;

namespace QuizDinossauros
{
    class Program
    {
        static void Main(string[] args)
        {
            int energia = 100;
            int pontos = 0;
            int fase = 1;
            int jogoRodando = 1; 
            int resposta;

            Console.WriteLine("EXPEDIÇÃO JURÁSSICA");
            Console.WriteLine("Você é um aventureiro tentando escapar de uma ilha!");
            Console.WriteLine("Acerte as perguntas para avançar ou perderá energia.");
            
            Console.Write("Iniciando GPS: ");
            for (int i = 0; i <= 100; i += 25)
            {
                Console.Write(i + "% ");
            }
            Console.WriteLine("\n");

            while (jogoRodando == 1 && energia > 0 && fase <= 3)
            {
                Console.WriteLine("INTEGRIDADE: " + energia + "% | FÓSSEIS: " + pontos);

                if (fase == 1)
                {
                    Console.WriteLine("FASE 1: O encontro com o herbívoro.");
                    Console.WriteLine("Qual destes dinossauros era conhecido pelo pescoço longo?");
                    Console.WriteLine("1) Tiranossauro Rex");
                    Console.WriteLine("2) Braquiossauro");
                    Console.WriteLine("3) Velociraptor");
                    Console.WriteLine("0) Desistir da expedição");
                }
                else if (fase == 2)
                {
                    Console.WriteLine("FASE 2: Fuga na floresta.");
                    Console.WriteLine("Qual era a principal dieta do Velociraptor?");
                    Console.WriteLine("1) Carne (Carnívoro)");
                    Console.WriteLine("2) Folhas (Herbívoro)");
                    Console.WriteLine("3) Insetos (Insetívoro)");
                    Console.WriteLine("0) Desistir da expedição");
                }
                else if (fase == 3)
                {
                    Console.WriteLine("FASE 3: O ninho do T-Rex.");
                    Console.WriteLine("Em qual período geológico viveram os dinossauros mais famosos?");
                    Console.WriteLine("1) Glacial");
                    Console.WriteLine("2) Cretáceo");
                    Console.WriteLine("3) Moderno");
                    Console.WriteLine("0) Desistir da expedição");
                }

                Console.Write("Sua escolha: ");
                resposta = int.Parse(Console.ReadLine());

                if (resposta == 0)
                {
                    jogoRodando = 0;
                }
                else if ((fase == 1 && resposta == 2) || (fase == 2 && resposta == 1) || (fase == 3 && resposta == 2))
                {
                    Console.WriteLine("CORRETO! Você ganhou 50 pontos.");
                    pontos = pontos + 50;
                    fase = fase + 1;
                }
                else
                {
                    Console.WriteLine("ERRADO! Um dinossauro te atacou.");
                    energia = energia - 40;
                }
            }

            if (fase > 3)
            {
                Console.WriteLine("VITÓRIA! Você chegou ao helicóptero de resgate!");
                Console.WriteLine("Pontuação Final: " + pontos);
            }
            else if (energia <= 0)
            {
                Console.WriteLine("DERROTA! Você virou comida de dinossauro.");
            }
            else
            {
                Console.WriteLine("DESISTÊNCIA: Você ficou para trás na ilha.");
            }
        }
    }
}