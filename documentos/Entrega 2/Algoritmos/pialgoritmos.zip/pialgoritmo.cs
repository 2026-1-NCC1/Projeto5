using System;

namespace QuizDinossauros
{
    class Program
    {
        static void Main(string[] args)
        {
            // DECLARAÇÃO DE VARIÁVEIS (ESTADO DO JOGO) 
            int energia = 100;      // Representa a "vida" do jogador
            int pontos = 0;         // Acumula a pontuação por acertos
            int fase = 1;           // Controla em qual etapa do jogo o jogador está
            int jogoRodando = 1;    // Flag (bandeira) para manter o loop ativo
            int resposta;           // Armazenará a entrada do usuário

            // INTRODUÇÃO E AMBIENTAÇÃO
            Console.WriteLine("EXPEDIÇÃO JURÁSSICA");
            Console.WriteLine("Você é um aventureiro tentando escapar de uma ilha!");
            Console.WriteLine("Acerte as perguntas para avançar ou perderá energia.");
            
            // Um pequeno charme visual: simula o carregamento de um GPS
            Console.Write("Iniciando GPS: ");
            for (int i = 0; i <= 100; i += 25)
            {
                Console.Write(i + "% ");
            }
            Console.WriteLine("\n");

            // LOOP PRINCIPAL DO JOGO
            // O jogo continua enquanto: o jogador não desistir, tiver vida e não passar da fase 3
            while (jogoRodando == 1 && energia > 0 && fase <= 3)
            {
                // Exibe o status atual do jogador no topo de cada rodada
                Console.WriteLine("INTEGRIDADE: " + energia + "% | FÓSSEIS: " + pontos);

                // SISTEMA DE PERGUNTAS POR FASE
                if (fase == 1)
                {
                    Console.WriteLine("FASE 1: O encontro com o herbívoro.");
                    Console.WriteLine("Qual destes dinossauros era conhecido pelo pescoço longo?");
                    Console.WriteLine("1) Tiranossauro Rex");
                    Console.WriteLine("2) Braquiossauro");
                    Console.WriteLine("3) Velociraptor");
                    Console.WriteLine("0) Desistir da expedição");
                }
                else if (fase == 2)
                {
                    Console.WriteLine("FASE 2: Fuga na floresta.");
                    Console.WriteLine("Qual era a principal dieta do Velociraptor?");
                    Console.WriteLine("1) Carne (Carnívoro)");
                    Console.WriteLine("2) Folhas (Herbívoro)");
                    Console.WriteLine("3) Insetos (Insetívoro)");
                    Console.WriteLine("0) Desistir da expedição");
                }
                else if (fase == 3)
                {
                    Console.WriteLine("FASE 3: O ninho do T-Rex.");
                    Console.WriteLine("Em qual período geológico viveram os dinossauros mais famosos?");
                    Console.WriteLine("1) Glacial");
                    Console.WriteLine("2) Cretáceo");
                    Console.WriteLine("3) Moderno");
                    Console.WriteLine("0) Desistir da expedição");
                }

                Console.Write("Sua escolha: ");
                // Converte o texto digitado pelo usuário para um número inteiro
                resposta = int.Parse(Console.ReadLine());

                // LÓGICA DE PROCESSAMENTO DA RESPOSTA 
                
                // Caso o jogador escolha 0, altera a flag para encerrar o loop
                if (resposta == 0)
                {
                    jogoRodando = 0;
                }
                // Verifica se a resposta está correta de acordo com a fase atual
                // Fase 1 resp: 2 | Fase 2 resp: 1 | Fase 3 resp: 2
                else if ((fase == 1 && resposta == 2) || (fase == 2 && resposta == 1) || (fase == 3 && resposta == 2))
                {
                    Console.WriteLine("CORRETO! Você ganhou 50 pontos.");
                    pontos = pontos + 50;   // Aumenta a pontuação
                    fase = fase + 1;         // Avança para a próxima fase
                }
                // Se não for a resposta correta e nem 0, o jogador errou
                else
                {
                    Console.WriteLine("ERRADO! Um dinossauro te atacou.");
                    energia = energia - 40;  // Penalidade de vida
                }
            }

            // TELAS DE FINALIZAÇÃO (PÓS-LOOP)

            if (fase > 3) // Se o jogador passou da última fase
            {
                Console.WriteLine("VITÓRIA! Você chegou ao helicóptero de resgate!");
                Console.WriteLine("Pontuação Final: " + pontos);
            }
            else if (energia <= 0) // Se a energia acabou
            {
                Console.WriteLine("DERROTA! Você virou comida de dinossauro.");
            }
            else // Caso o loop tenha parado porque o jogador escolheu desistir (jogoRodando = 0)
            {
                Console.WriteLine("DESISTÊNCIA: Você ficou para trás na ilha.");
            }
        }
    }
}